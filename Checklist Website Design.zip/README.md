
  # Checklist Website Design

  This is a code bundle for Checklist Website Design. The original project is available at https://www.figma.com/design/CyT3Q4Rn48DHKDHZ7SVxvu/Checklist-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  